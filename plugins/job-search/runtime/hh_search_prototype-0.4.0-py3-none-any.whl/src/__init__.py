"""Independent HH search prototype."""
