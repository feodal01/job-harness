"""Source-independent search conditions. Site IDs never belong in a brief."""

from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from src.geography.countries import country_codes

WorkFormat = Literal["office", "hybrid", "remote_country", "remote_worldwide"]
Employment = Literal["full_time", "part_time", "contract", "internship", "volunteer"]
Grade = Literal["intern", "junior", "middle", "senior", "lead"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SearchPlace(StrictModel):
    country: str
    scope: Literal["city", "country"] = Field(
        default="city",
        description="city requires a selected GeoNames ID; country explicitly selects the whole country",
    )
    city: str | None = Field(default=None, min_length=1, max_length=200)
    region: str | None = Field(default=None, min_length=1, max_length=100)
    geoname_id: int | None = Field(
        default=None, gt=0, description="Selected GeoNames ID; required for scope=city"
    )
    country_name_en: str | None = None
    city_display_name: str | None = Field(
        default=None,
        min_length=1,
        max_length=400,
        description="Full name from the city suggestion; required for scope=city",
    )
    minimum_work_format: WorkFormat | None = Field(
        default=None, description="Minimum work format for this location; more flexible formats also qualify"
    )
    relocation_support: bool | None = Field(
        default=None, description="Require employer relocation assistance for this location"
    )

    @field_validator("country")
    @classmethod
    def known_country(cls, value: str) -> str:
        if value not in country_codes():
            raise ValueError("Choose a country from the catalog")
        return value

    @model_validator(mode="after")
    def region_needs_city(self) -> "SearchPlace":
        if self.scope == "country" and any(
            value is not None for value in (self.city, self.region, self.geoname_id, self.city_display_name)
        ):
            raise ValueError("Whole-country selection must not contain city or region data")
        if self.region and not self.city:
            raise ValueError("Region requires a city")
        return self


class SalaryFilter(StrictModel):
    minimum: float = Field(gt=0, allow_inf_nan=False)
    currency: str = Field(pattern=r"^[A-Z]{3}$")
    period: Literal["month", "year", "hour"]


class SearchFilters(StrictModel):
    locations: list[SearchPlace] = Field(default_factory=list, max_length=20)
    minimum_work_format: WorkFormat | None = Field(
        default=None,
        description="Historical general condition; use locations[].minimum_work_format for new briefs",
        json_schema_extra={"deprecated": True},
    )
    employment: list[Employment] = Field(default_factory=list, max_length=5)
    experience_years: float | None = Field(default=None, ge=0, le=80, allow_inf_nan=False)
    salary: SalaryFilter | None = None
    published_after: date | None = None
    relocation_support: bool = Field(
        default=False,
        description="Historical general condition; use locations[].relocation_support for new briefs",
        json_schema_extra={"deprecated": True},
    )
    excluded_companies: list[str] = Field(default_factory=list, max_length=50)
    excluded_text: list[str] = Field(default_factory=list, max_length=50)

    def location_conditions(self, place: SearchPlace | None) -> tuple[WorkFormat | None, bool]:
        """Read historical general conditions until a brief is resaved with per-city conditions."""
        minimum = place.minimum_work_format if place else None
        relocation = place.relocation_support if place else None
        return (
            minimum if minimum is not None else self.minimum_work_format,
            relocation if relocation is not None else self.relocation_support,
        )

    @field_validator("excluded_companies", "excluded_text")
    @classmethod
    def nonempty_terms(cls, values: list[str]) -> list[str]:
        if any(not v.strip() or len(v) > 200 for v in values):
            raise ValueError("Conditions must contain 1–200 characters")
        return list(dict.fromkeys(v.strip() for v in values))


class WorkLocation(StrictModel):
    country: str | None = None
    city: str | None = None
    format: WorkFormat | None = None
    excluded: bool = False
    worldwide: bool = False

    @field_validator("format", mode="before")
    @classmethod
    def legacy_remote(cls, value: object) -> object:
        return "remote_country" if value == "remote" else value


Status = Literal["accepted", "rejected", "unknown"]


class FilterCheck(StrictModel):
    field: str
    status: Status
    reason: str
    kind: Literal["hard", "soft"] = "soft"
    supported: bool = True


class FilterResult(StrictModel):
    status: Literal["accepted", "maybe", "rejected"]
    checks: list[FilterCheck]
