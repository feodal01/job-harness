"""ashby public board parser."""
