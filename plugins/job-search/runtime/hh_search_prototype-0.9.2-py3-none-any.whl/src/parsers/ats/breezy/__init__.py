"""breezy public board parser."""
