"""bamboohr public board parser."""
