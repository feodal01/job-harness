"""huntflow public board parser."""
