"""workable public board parser."""
