"""Indexed read-only lookup for chosen cities; independent of HTTP and source adapters."""

import json
import sqlite3
import unicodedata
from contextlib import closing
from functools import lru_cache
from pathlib import Path
from typing import Any

from src.core.errors import InvalidSearchError
from src.geography.countries import DEFAULT_LOCALE, country_codes, country_names

DATABASE = Path(__file__).with_name("data") / "cities.sqlite"


def normalize(value: str) -> str:
    return unicodedata.normalize("NFC", " ".join(value.casefold().split()))


class CityLookup:
    def __init__(self, database_path: Path = DATABASE) -> None:
        self.path = database_path.resolve(strict=True)
        self.uri = self.path.as_uri() + "?mode=ro"
        with closing(self.connect()) as c:
            if c.execute("PRAGMA user_version").fetchone()[0] != 1:
                raise RuntimeError("Unsupported geography database format")
            if c.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise RuntimeError("Corrupt geography database")
            metadata = json.loads(c.execute("SELECT value FROM metadata WHERE key='build'").fetchone()[0])
            if metadata["format_version"] != 1 or metadata["dataset"] != "cities15000":
                raise RuntimeError("Unexpected geography dataset")

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.uri, uri=True)
        connection.row_factory = sqlite3.Row
        return connection

    def search(self, country: str, text: str, locale: str = DEFAULT_LOCALE) -> list[dict[str, Any]]:
        labels = country_names(locale)
        if country not in country_codes():
            raise InvalidSearchError("Choose an ISO country from the catalog")
        query = normalize(text)
        if not 1 <= len(query) <= 100:
            raise InvalidSearchError("Enter 1–100 city characters")
        with closing(self.connect()) as c:
            found = c.execute(
                """
                WITH candidates AS (
                    SELECT city_id, name, search_key,
                        ROW_NUMBER() OVER (PARTITION BY city_id ORDER BY
                            CASE WHEN search_key=? THEN 0 ELSE 1 END,
                            historic, colloquial, preferred DESC, length(name), name, language) AS position
                    FROM names WHERE country=? AND search_key>=? AND search_key<?
                )
                SELECT cities.*, candidates.name AS display_name, candidates.search_key=? AS exact
                FROM candidates JOIN cities ON cities.geoname_id=candidates.city_id
                WHERE position=1 ORDER BY exact DESC, population DESC, geoname_id LIMIT 20
            """,
                (query, country, query, query + "\U0010ffff", query),
            ).fetchall()
        return [self.response(dict(row), row["display_name"], labels[country]) for row in found]

    def response(self, city: dict[str, Any], display_name: str, country_label: str) -> dict[str, Any]:
        return {
            "geoname_id": city["geoname_id"],
            "country": city["country"],
            "country_name_en": country_names()[city["country"]],
            "name": display_name,
            "ascii_name": city["ascii_name"],
            "region": city["region"],
            "path": [country_label] + ([city["region"]] if city["region"] else []),
        }

    def get(self, geoname_id: int) -> dict[str, Any]:
        with closing(self.connect()) as c:
            row = c.execute("SELECT * FROM cities WHERE geoname_id=?", (geoname_id,)).fetchone()
        if row is None:
            raise InvalidSearchError("Choose a city from the suggestions")
        return dict(row)

    def resolve(self, country: str, geoname_id: int, display_name: str) -> dict[str, Any]:
        city = self.get(geoname_id)
        if city["country"] != country:
            raise InvalidSearchError("Selected city does not belong to the country")
        with closing(self.connect()) as c:
            alias = c.execute(
                "SELECT name FROM names WHERE country=? AND search_key=? AND city_id=? "
                "ORDER BY historic,colloquial,preferred DESC,name LIMIT 1",
                (country, normalize(display_name), geoname_id),
            ).fetchone()
        if alias is None:
            raise InvalidSearchError("Select the full city name from the suggestions")
        return self.response(city, alias["name"], country_names()[country])

    def label(self, geoname_id: int, language: str) -> str:
        city = self.get(geoname_id)
        with closing(self.connect()) as c:
            alias = c.execute(
                "SELECT name FROM names WHERE city_id=? AND language=? "
                "AND historic=0 AND colloquial=0 ORDER BY preferred DESC,name LIMIT 1",
                (geoname_id, language),
            ).fetchone()
        # A source request uses an available localized name, otherwise the canonical ASCII name.
        return alias["name"] if alias else city["ascii_name"]

    def matches(self, geoname_id: int, actual: str, regions: tuple[str, ...] = ()) -> bool | None:
        city = self.get(geoname_id)
        from src.geography.names import split_city

        name, qualifier = split_city(actual)
        with closing(self.connect()) as c:
            candidates = {
                r[0]: r[1]
                for r in c.execute(
                    "SELECT DISTINCT city_id,region_id FROM names "
                    "JOIN cities ON cities.geoname_id=names.city_id "
                    "WHERE names.country=? AND search_key=?",
                    (city["country"], normalize(name)),
                )
            }
            if geoname_id not in candidates:
                return False if candidates else None
            for region in (*regions, *([qualifier] if qualifier else [])):
                region_ids = {
                    row[0]
                    for row in c.execute(
                        "SELECT DISTINCT region_names.region_id FROM region_names "
                        "JOIN cities ON cities.region_id=region_names.region_id "
                        "WHERE cities.country=? AND region_names.search_key=?",
                        (city["country"], normalize(region)),
                    )
                }
                if region_ids:
                    candidates = {gid: rid for gid, rid in candidates.items() if rid in region_ids}
                    if geoname_id not in candidates:
                        return False
                elif region == qualifier:
                    # An explicit but unknown qualifier cannot establish city identity.
                    return None
        return True if len(candidates) == 1 else None


@lru_cache(maxsize=1)
def default_lookup() -> CityLookup:
    return CityLookup()
