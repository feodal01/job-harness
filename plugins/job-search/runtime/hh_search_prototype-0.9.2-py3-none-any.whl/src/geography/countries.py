"""Countries supported by the common search brief."""

import gzip
import json
from functools import lru_cache
from pathlib import Path

from src.core.errors import InvalidSearchError

# Initial supported country list; adapters resolve their own IDs at request time.
COUNTRIES = {
    "RU": "Россия",
    "BY": "Беларусь",
    "KZ": "Казахстан",
    "AM": "Армения",
    "UZ": "Узбекистан",
    "KG": "Кыргызстан",
    "AZ": "Азербайджан",
    "GE": "Грузия",
    "UA": "Украина",
    "MD": "Молдова",
    "RS": "Сербия",
    "ME": "Черногория",
    "TR": "Турция",
    "CY": "Кипр",
    "AE": "ОАЭ",
    "IL": "Израиль",
    "DE": "Германия",
    "PL": "Польша",
    "NL": "Нидерланды",
    "FR": "Франция",
    "ES": "Испания",
    "PT": "Португалия",
    "GB": "Великобритания",
    "US": "США",
    "CA": "Канада",
    "AU": "Австралия",
    "TH": "Таиланд",
    "ID": "Индонезия",
    "VN": "Вьетнам",
    "SG": "Сингапур",
    "CH": "Швейцария",
    "CZ": "Чехия",
}


# The legacy labels above remain private to the existing vacancy/native-source normalization.
# The public country catalog is generated from all assigned ISO codes and CLDR.
DEFAULT_LOCALE = "en"


@lru_cache(maxsize=1)
def country_catalog() -> dict:
    return json.loads(
        gzip.decompress(Path(__file__).with_name("data").joinpath("countries.json.gz").read_bytes())
    )


def country_names(locale: str = DEFAULT_LOCALE) -> dict[str, str]:
    locales = country_catalog()["locales"]
    if locale not in locales:
        raise InvalidSearchError(f"Unsupported geography locale: {locale}")
    return locales[locale]


def country_codes() -> frozenset[str]:
    return frozenset(country_catalog()["countries"])
