from typing import Any

from src.geography.countries import DEFAULT_LOCALE, country_names
from src.geography.lookup import CityLookup


class GeographyService:
    def __init__(self, directory: CityLookup) -> None:
        self.directory = directory

    def countries(self, locale: str = DEFAULT_LOCALE) -> list[dict[str, str]]:
        return [{"code": code, "name": name} for code, name in country_names(locale).items()]

    def cities(self, country: str, text: str, locale: str = DEFAULT_LOCALE) -> list[dict[str, Any]]:
        return self.directory.search(country, text, locale)
